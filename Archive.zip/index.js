var express = require("express");
var bodyParser = require("body-parser");
var app = express();
app.use(express.static(__dirname + "/public"));

// app.set("port", process.env.PORT || 5000);
// app.use(express.static(__dirname + "/public"));
// app.set("views", __dirname + "/public");

//POST METHOD view html file
//npm install --save ejs
app.engine("html", require("ejs").renderFile);
app.set("view engine", "html");

function sum(a, b) {
    return a + b;
}

//Here we are configuring express to use body-parser as middle-ware.
app.use(bodyParser.urlencoded({ extended: false }));
// app.use(bodyParser.json());

app.get("/", function(req, res) {
  var test = ["<b>MEAN STACK</b>"];
  test += ["<br>"];
  test += [
    "<ul><li>Mongo DB</li><li>Express</li><li>Angular</li><li>Node.js</li></ul>"
  ];
  res.send(test);
});

app.get("/test", function(req, res) {
  res.redirect("test.html");
  // res.sendFile("test.html");
});

app.get("/About", function(req, res) {
  var arr = ["PHP", "NODE.js", "ASP.NET CORE"];
  res.send("Hello " + arr[1]);
});

app.get("/csstest", function(req, res) {
  var str = ["<span style='color:red;'>I am beginner of Node.js</span>"];
  res.send("Hello, " + str);
});

app.get("/fx", function(req, res) {
  res.send("3 + 4 = " + sum(3, 4));
});

app.get("/math", function(req, res) {
  var a = 5 * 2 + 7 - 3;
  res.send("5*2+7-3" + " = " + (5 * 2 + 7 - 3).toString());
  // res.render('index',{title:a.toString()});
  // #{title}
});

app.get("/usr", function(req, res) {
  var queryParameter = req.query;
  res.json(queryParameter);
  console.log(queryParameter.inputEmail3);
  console.log(queryParameter.inputPassword3);
});

app.post("/fpost", function(req, res) {
  var name = req.body.validationCustom01;
  console.log(name);
  // res.send(req.body);
  res.render(__dirname + "/public/main.html", { uname: name });
  // res.render("main.html", { uname: name });
});

app.listen(3000, function() {
  console.log("Express running on port 3000");
});